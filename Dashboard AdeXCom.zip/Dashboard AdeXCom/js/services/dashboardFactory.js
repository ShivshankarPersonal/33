angular.module('dashboard')
    .factory('dashboardFactory', function ($http, $q) {
        return {
            fetchData: function (url) {
                var deferred = $q.defer();
                $http.get('./data/' + url + '.json').success(function (data, status, headers, config) {
                    deferred.resolve(data, status, headers, config);
                }).error(function (data, status, headers, config) {
                    deferred.reject(data, status, headers, config);
                });
                return deferred.promise;
            }
        };
    });