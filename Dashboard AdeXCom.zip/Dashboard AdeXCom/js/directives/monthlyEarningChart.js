angular.module('dashboard')
    .directive('monthlyEarningChart', function () {
        return {
            restrict: 'E',
            controller: function ($scope) {
                $scope.onMonthlyEarningChartClick = function () {
                    $('#myModal').modal('show');
                    $('#myModal').on('shown.bs.modal',function(event){
                        $('#modalBody').empty();
                        drawChart("#modalBody");
                    });
                };
                drawChart('#monthlyEarningChart');
                function drawChart(containerID) {
                    var margin = {top: 22, right: 25, bottom: 40, left: 50},
                        width = $(containerID).width() - margin.left - margin.right,
                        height = $(containerID).width() - margin.top - margin.bottom - 400;
                    if(width < 500){
                        height = $(containerID).width()
                    }
                    console.log(height)
                    console.log(width)
                    var x = d3.scaleLinear().range([0, width]);
                    var y = d3.scaleLinear().range([height, 0]);
                    var area = d3.area()
                        .x(function (d) {
                            return x(d.date);
                        })
                        .y0(height)
                        .y1(function (d) {
                            return y(d.close);
                        });
                    var valueline = d3.line()
                        .curve(d3.curveMonotoneX)
                        .x(function (d) {
                            return x(d.date);
                        })
                        .y(function (d) {
                            return y(d.close);
                        });
                    var valueline2 = d3.line()
                        .curve(d3.curveMonotoneX)
                        .x(function (d) {
                            return x(d.date);
                        })
                        .y(function (d) {
                            return y(d.start);
                        });
                    var svg = d3.select(containerID).append("svg")
                        .attr("width", width + margin.left + margin.right)
                        .attr("height", height + margin.top + margin.bottom)
                        .append("g")
                        .attr("transform",
                            "translate(" + margin.left + "," + margin.top + ")");

                    function make_x_gridlines() {
                        return d3.axisBottom(x)
                            .ticks(8)
                    }
                    function make_y_gridlines() {
                        return d3.axisLeft(y)
                            .ticks(8)
                    }
                    d3.json("data/monthlyEarningData.json", function (error, data) {
                        if (error) throw error;
                        data.forEach(function (d) {
                            d.date = +d.date;
                            d.close = +d.close;
                        });
                        x.domain(d3.extent(data, function (d) {
                            return d.date;
                        }));
                        y.domain([0, d3.max(data, function (d) {
                            return d.close;
                        })]);
                        svg.append("path")
                            .data([data])
                            .attr("class", "area")
                            .attr("d", area);
                        svg.append("path")
                            .data([data])
                            .attr("class", "line")
                            // .style("stroke-dotarray", ("3,3"))
                            .style("stroke-linejoin", 'round')
                            .style("stroke", 'rgb( 246,22,26)')
                            .attr("d", valueline);
                        svg.append("path")
                            .data([data])
                            .attr("class", "line startLine")
                            // .style("stroke-dotarray", ("3,3"))
                            .style("stroke-linejoin", 'round')
                            .style("stroke", 'rgb(3,203,255)')
                            .attr("d", valueline2);
                        svg.selectAll("dot")
                            .data(data)
                            .enter().append("circle")
                            .attr("class", "dot")
                            .attr("r", 5)
                            .attr("cx", function (d) {
                                return x(d.date);
                            })
                            .attr("cy", function (d) {
                                return y(d.close);
                            });
                        svg.selectAll("dot")
                            .data(data)
                            .enter().append("circle")
                            .attr("class", "startDot")
                            .attr("r", 5)
                            .attr("cx", function (d) {
                                return x(d.date);
                            })
                            .attr("cy", function (d) {
                                return y(d.start);
                            });
                        svg.append("g")
                            .attr("transform", "translate(0," + height + ")")
                            .call(d3.axisBottom(x));
                        svg.append("g")
                            .call(d3.axisLeft(y));
                        svg.append('rect')
                            .attr("x", (width / 2) - 190)
                            .attr("y", 0 - (margin.top / 2)-9)
                            .attr('width', 10)
                            .attr('height', 10)
                            .style('fill', 'rgb( 246,22,26)')
                            .style('stroke', 'rgb( 246,22,26)');
                        svg.append("text")
                            .attr("x", (width / 2) - 140)
                            .attr("y", 0 - margin.top / 2)
                            .attr("text-anchor", "middle")
                            .style("font", "14px Verdana")
                            //.style("text-decoration", "underline")
                            .style("fill", "rgb( 246,22,26)")
                            .text("1000K+");
                        svg.append('rect')
                            .attr("x", (width / 2) - 50)
                            .attr("y", 0 - (margin.top / 2) - 9)
                            .attr('width', 10)
                            .attr('height', 10)
                            .style('fill', 'rgb(3,203,255)')
                            .style('stroke', 'rgb(3,203,255)');
                        svg.append("text")
                            .attr("x", width / 2)
                            .attr("y", 0 - margin.top / 2)
                            .attr("text-anchor", "middle")
                            .style("font", "14px Verdana")
                            .style("fill", "rgb(3,203,255)")
                            //.style("text-decoration", "underline")
                            .text("5000K+");
                        svg.append("g")
                            .attr("class", "grid")
                            .attr("transform", "translate(0," + height + ")")
                            .call(make_x_gridlines()
                                .tickSize(-height)
                                .tickFormat("")
                            );
                        svg.append("g")
                            .attr("class", "grid")
                            .call(make_y_gridlines()
                                .tickSize(-width)
                                .tickFormat("")
                            )
                    });
                }
            }
        }
    });