
angular.module('dashboard')
    .directive('rounderChart', function () {
        return {
            restrict: 'E',
            controller: function ($scope) {
                drawChart('#rounderChart');
                function drawChart(containerID) {
                    $scope.onRounderChartClick = function () {
                        $('#myModal').modal('show');
                        $('#myModal').on('shown.bs.modal',function(event){
                            $('#modalBody').empty();
                            drawChart("#modalBody");
                        });
                    };
                    var dataset = [
                        {technology: "AngularJS", value: 540},
                        {technology: "ReactJS", value: 1550},
                        {technology: "NodeJS", value: 940},
                        {technology: "jQuery", value: 379},
                        {technology: "D3 & Ag-Grid", value: 2072},
                        {technology: "Others", value: 172}
                    ];

                    var width = 0;
                    var height = 0;
                    if(containerID === '#modalBody'){
                        width = $(containerID).width()*.7;
                        height = $(containerID).width()*.7;
                    }else{
                        width = $(containerID).width() - 20;
                        height = $(containerID).width() - 20;
                    }
                    var radius = Math.min(width, height) / 2;

                    var color = d3.scaleOrdinal(d3.schemeCategory20c);

                    var svg = d3.select(containerID)
                        .append('svg')
                        .attr('width', width)
                        .attr('height', height)
                        .append('g')
                        .attr('transform', 'translate(' + (width / 2) +
                            ',' + (height / 2) + ')');

                    var donutWidth = 75;

                    var arc = d3.arc()
                        .innerRadius(radius - donutWidth + 40)
                        .outerRadius(radius);

                    var pie = d3.pie()
                        .value(function(d) { return d.value; })
                        .sort(null);

                    var legendRectSize = 10;
                    var legendSpacing = 4;

                    var path = svg.selectAll('path')
                        .data(pie(dataset))
                        .enter()
                        .append('path')
                        .attr('d', arc)
                        .attr('fill', function(d, i) {
                            return color(d.data.technology);

                        });
                    var legend = svg.selectAll('.legend')
                        .data(color.domain())
                        .enter()
                        .append('g')
                        .attr('class', 'legend')
                        .attr('transform', function(d, i) {
                            var height = legendRectSize + legendSpacing;
                            var offset =  height * color.domain().length / 2;
                            var horz = -2 * legendRectSize;
                            var vert = i * height - offset;
                            return 'translate(' + horz + ',' + vert + ')';
                        });

                    legend.append('rect')
                        .attr('width', legendRectSize)
                        .attr('height', legendRectSize)
                        .style('fill', color)
                        .style('stroke', color);

                    legend.append('text')
                        .attr('x', legendRectSize + legendSpacing)
                        .attr('y', legendRectSize - legendSpacing)
                        .style('font-size','10px')
                        .text(function(d) { return d; });
                }
            }
        }
    });