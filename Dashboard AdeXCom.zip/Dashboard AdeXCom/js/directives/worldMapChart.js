
angular.module('dashboard')
    .directive('worldMapChart', function () {
        return {
            restrict: 'E',
            template: '<div id="worldMap" ng-click="onWorldMapChartClick();"></div>',
            controller: function ($scope) {
                $scope.onWorldMapChartClick = function () {
                    $('#myModal').modal('show');
                    $('#myModal').on('shown.bs.modal',function(event){
                        $('#modalBody').empty();
                        drawChart("#modalBody");
                    });
                };
                drawChart('#worldMap');
                function drawChart(containerID) {
                    var format = d3.format(",");

                    // Set tooltips
                    var tip = d3.tip()
                        .attr('class', 'd3-tip')
                        .offset([-10, 0])
                        .html(function(d) {
                            return "<strong>Country: </strong><span class='details'>" + d.properties.name + "<br></span>" + "<strong>Population: </strong><span class='details'>" + format(d.population) +"</span>";
                        });

                    var margin = {top: 0, right: 5, bottom: 0, left: 5},
                        width = $(containerID).width() - margin.left - margin.right,
                        height = $(containerID).width() - margin.top - margin.bottom;

                    if(containerID === "#modalBody"){
                        height = $(containerID).width() - margin.top - margin.bottom - 300 ;
                    }

                    var color = d3.scaleThreshold()
                        .domain([10000,100000,500000,1000000,5000000,10000000,50000000,100000000,500000000,1500000000])
                        .range(["rgb(38, 84, 124)", "rgb(38, 84, 124)", "rgb(0, 222, 255)", "rgb(0, 222, 255)", "rgb(0,222,255)", "rgb(0,222,255)","rgb(0, 222, 255)","rgb(0,222,255)","rgb(255,0,132)","rgb(255, 0, 132)"]);
                        //.range(['red','green','blue','yellow']);

                    var path = d3.geoPath();

                    var svg = d3.select(containerID)
                        .append("svg")
                        .attr("width", width)
                        .attr("height", height)
                        .append('g')
                        .attr('class', 'map');
                    var scale = 40;
                    if(containerID === "#modalBody"){
                        scale = 120;
                    }
                    var projection = d3.geoMercator()
                        .scale(scale)
                        .translate( [width / 2, height / 1.5]);

                    var path = d3.geoPath().projection(projection);

                    svg.call(tip);

                    queue()
                        .defer(d3.json, "data/worldCountries.json")
                        .defer(d3.tsv, "data/worldPopulation.tsv")
                        .await(ready);

                    function ready(error, data, population) {
                        var populationById = {};

                        population.forEach(function(d) { populationById[d.id] = +d.population; });
                        data.features.forEach(function(d) { d.population = populationById[d.id] });

                        svg.append("g")
                            .attr("class", "countries")
                            .selectAll("path")
                            .data(data.features)
                            .enter().append("path")
                            .attr("d", path)
                            .style("fill", function(d) {
                                return color(populationById[d.id]);
                            })
                            .style('stroke', 'white')
                            .style('stroke-width', 1.5)
                            .style("opacity",1)
                            // tooltips
                            .style("stroke","white")
                            .style('stroke-width', 0.3)
                            .on('mouseover',function(d){
                                tip.show(d);

                                d3.select(this)
                                    .style("opacity", 1)
                                    .style("stroke","white")
                                    .style("stroke-width",3);
                            })
                            .on('mouseout', function(d){
                                tip.hide(d);

                                d3.select(this)
                                    .style("opacity", 0.8)
                                    .style("stroke","white")
                                    .style("stroke-width",0.3);
                            });

                        svg.append("path")
                            .datum(topojson.mesh(data.features, function(a, b) { return a.id !== b.id; }))
                            // .datum(topojson.mesh(data.features, function(a, b) { return a !== b; }))
                            .attr("class", "names")
                            .attr("d", path);
                    }
                }
            }
        }
    });