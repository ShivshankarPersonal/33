angular.module('dashboard')
    .directive('progressChart', function () {
        return {
            restrict: 'E',
            controller: function ($scope, $element, $attrs) {

                $scope.onprogressChart0Click = function ($event) {
                    $('#myModal').modal('show');
                    $('#modalBody').width($(window).width()*.8)
                    $('#modalBody').height($(window).width()*.8)
                    $('#myModal').on('shown.bs.modal',function(event){
                        $('#modalBody').empty();
                        var containerID = $($event.currentTarget).find('progress-chart').attr('identifier'),
                            percent = parseInt($($event.currentTarget).find('progress-chart').attr('percent')),
                            startcolor = $($event.currentTarget).find('progress-chart').attr('startcolor'),
                            endcolor = $($event.currentTarget).find('progress-chart').attr('endcolor');
                        drawChart("modalBody", percent, startcolor, endcolor);
                    });
                    $("#myModal").on('hidden.bs.modal', function () {
                        $('#modalBody').width('auto');
                        $('#modalBody').height('auto');
                    })
                };
                if (containerID !== "modalBody") {
                    var containerID = $attrs.identifier,
                        percent = parseInt($attrs.percent),
                        startcolor = $attrs.startcolor,
                        endcolor = $attrs.endcolor;
                }
                drawChart(containerID, percent, startcolor, endcolor);
                function drawChart(containerID, percent, startcolor, endcolor) {
                    var createGradient = function (svg, id, color1, color2) {
                        var defs = svg.append("svg:defs");
                        var red_gradient = defs.append("svg:linearGradient")
                            .attr("id", id)
                            .attr("x1", "0%")
                            .attr("y1", "0%")
                            .attr("x2", "0%")
                            .attr("y2", "100%")
                            .attr("spreadMethod", "pad");
                        red_gradient.append("svg:stop")
                            .attr("offset", "50%")
                            .attr("stop-color", color1)
                            .attr("stop-opacity", 1);
                        red_gradient.append("svg:stop")
                            .attr("offset", "100%")
                            .attr("stop-color", color2)
                            .attr("stop-opacity", 1);
                    };
                    var ratio = percent / 100;
                    var pie = d3.pie()
                        .value(function (d) {
                            return d
                        })
                        .sort(null);
                    var w, h, outerRadius, innerRadius;
                    if (containerID === "modalBody") {
                        w = $('#modalBody').width()*.6;
                        h = $('#modalBody').height()*.6;
                        outerRadius = (w / 2);
                        innerRadius = outerRadius - outerRadius*.3;

                    } else {
                        w = $('#' + containerID).width() - 10;
                        h = $('#' + containerID).width() - 10;
                        outerRadius = (w / 2);
                        innerRadius = outerRadius - 20;
                    }
                    var color = [];
                    color[0] = startcolor;
                    color[1] = endcolor;
                    color[2] = 'rgb(240,240,240)';
                    var svg = d3.select('#' + containerID)
                        .append("svg")
                        .attrs({
                            width: w,
                            height: h,
                            class: 'shadow'
                        }).append('g')
                        .attrs({
                            transform: 'translate(' + w / 2 + ',' + h / 2 + ')'
                        });
                    var ids = 'gradient' + containerID;
                    var urls = '#' + ids;
                    createGradient(svg, 'gradient' + containerID, color[0], color[1]);
                    // createGradient(svg, ids, color[0], color[1]);
                    var arc = d3.arc()
                        .innerRadius(innerRadius)
                        .outerRadius(outerRadius)
                        .startAngle(0)
                        .endAngle(2 * Math.PI);

                    var arcLine = d3.arc()
                        .innerRadius(innerRadius)
                        .outerRadius(outerRadius)
                        .startAngle(0);
                    var pathBackground = svg.append('path')
                        .attrs({
                            d: arc
                        })
                        .styles({
                            fill: color[2]
                        });
                    var pathChart = svg.append('path')
                        .datum({endAngle: 0})
                        .attrs({
                            d: arcLine
                        })
                        .styles({
                            fill: 'url(' + urls + ')'
                        });
                    var middleCount = svg.append('text')
                        .text(function (d) {
                            return d;
                        })
                        .attrs({
                            class: 'middleText',
                            'text-anchor': 'middle',
                            dy: 10,
                            dx: 15
                        })
                        .styles({
                            fill: 'url(' + urls + ')',
                            'font-size': '20px'
                        });
                    svg.append('text')
                        .text('%')
                        .attrs({
                            class: 'percent',
                            'text-anchor': 'middle',
                            dx: -10,
                            dy: 10
                        })
                        .styles({
                            fill: 'url(' + urls + ')',
                            'font-size': '20px'
                        });
                    var arcTween = function (transition, newAngle) {
                        transition.attrTween("d", function (d) {
                            var interpolate = d3.interpolate(d.endAngle, newAngle);
                            var interpolateCount = d3.interpolate(0, percent);
                            return function (t) {
                                d.endAngle = interpolate(t);
                                middleCount.text(Math.floor(interpolateCount(t)));
                                return arcLine(d);
                            };
                        });
                    };
                    var animate = function () {
                        pathChart.transition()
                            .duration(2000)
                            .call(arcTween, ((2 * Math.PI)) * ratio);
                    };
                    //animate();
                     setTimeout(animate, 0);
                }
            }
        }
    });
